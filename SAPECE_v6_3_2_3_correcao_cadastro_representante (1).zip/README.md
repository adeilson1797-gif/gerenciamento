SAPECE v6.3.2.3 — correção de cadastro parcial / usuário já registrado

# SAPECE v6.3.2.2

Correção de visibilidade da função **Liberar Dia**.

- Novo botão **🔓 LIBERAR DIA** no topo do painel gerencial, ao lado de Painel Gerencial e Comissão.
- Disponível para Administrador Geral, Subadministrador e Gerente Regional.
- Ao clicar, o sistema abre e centraliza a área de liberação.
- Os pedidos já finalizados continuam intactos e bloqueados; a liberação permite apenas novos pedidos na data escolhida.

# SAPECE v6.3.2

## Novidade
- Administrador Geral, Subadministrador e Gerente Regional agora possuem a área **Liberar dia para novos pedidos**.
- Ao liberar um dia já finalizado, os pedidos antigos continuam finalizados/bloqueados.
- O representante pode adicionar somente novos pedidos e depois finalizar o dia novamente.
- O novo fechamento consolida o total completo do dia e dispara novamente o resumo atualizado por e-mail.

# Acompanhamento Gerencial

Projeto web para coleta online do valor total de vendas diárias de representantes comerciais.

## O que já está pronto

- Supabase real configurado
- Login com e-mail e senha
- Primeiro administrador por auto cadastro
- Convites para representantes
- Cada representante vê apenas os próprios dados
- Administrador vê toda a equipe
- Lançamento diário simples: data + valor + observação
- Um único lançamento por representante por data
- Correção do mesmo dia via atualização
- Meta mensal individual
- Indicador de quem já lançou hoje
- Painel gerencial por mês
- Recuperação de senha
- Segurança RLS no banco

## Banco configurado

Projeto Supabase: Acompanhamento Gerencial
Região: São Paulo

O `config.js` já está apontando para o projeto criado.

## Como testar localmente

Sirva a pasta com qualquer servidor HTTP. Exemplo:

```bash
python -m http.server 8080
```

Depois abra:
http://localhost:8080

## Primeiro acesso

1. Abra o sistema.
2. Clique em `Primeiro acesso`.
3. Cadastre seu nome, e-mail e senha.
4. Se o Supabase solicitar confirmação de e-mail, confirme e faça login.
5. O primeiro perfil válido pode se tornar administrador usando a função segura de bootstrap.

## Como cadastrar representantes

1. Entre como administrador.
2. Em `Gerar convite de representante`, informe nome e meta.
3. Copie o código.
4. Envie o código ao representante.
5. O representante abre a aba `Representante`, informa código, e-mail e senha.
6. O perfil é criado automaticamente.

## Publicação

A pasta está pronta para publicação estática em Vercel, Netlify ou GitHub Pages.
Para publicar pela Vercel, conecte o plugin Vercel no ChatGPT e o projeto poderá ser implantado por lá.


## Evolução gerencial v2

- Ranking mensal automático
- Evolução diária em gráfico
- Contagem de representantes ativos, lançados e pendentes
- Meta restante e média necessária por dia útil
- Edição de nome/meta pelo administrador
- Desativação de representante sem perder histórico
- Exportação CSV do mês
- Barra de progresso individual da meta


## Evolução v3

- Crédito na tela de login: **Projeto pessoal — Especialista Escobar-PB**
- Crédito também no rodapé do sistema
- Comparação de vendas de hoje x ontem
- Projeção de fechamento do mês
- Valor restante para a meta
- Necessidade média por dia útil restante
- Histórico administrativo de lançamentos
- Correção de valor/observação pelo administrador
- Filtro do histórico por data
- Arquivo `vercel.json` pronto para publicação
- `package.json` incluído para facilitar testes e deploy


## Evolução v4
- Status diário corrigido: R$ 0,00 conta como informado
- Status Com venda / Sem venda / Pendente
- Contador Já informaram hoje corrigido
- Datas locais para evitar diferença de UTC
- Recuperação de senha com nova senha
- Filtros por representante e período
- Exportação Excel .xlsx
- Relatório para impressão/PDF


## Correção v4.1

- Corrigido erro que escondia a tela de login após o deploy.
- Adicionada a tela de recuperação de senha que estava referenciada pelo JavaScript, mas ausente no HTML.
- `showOnly()` agora é tolerante a elementos opcionais ausentes, evitando que a interface inteira seja ocultada por erro de JavaScript.


## Evolução v4.2 — Subadministrador

- Novo perfil `sub_admin` no Supabase.
- Administrador principal pode gerar convite para **Representante** ou **Subadministrador**.
- Subadministrador acessa o painel gerencial completo de vendas.
- Subadministrador pode consultar histórico, filtrar, exportar e corrigir lançamentos.
- Cadastro, edição, desativação de usuários e geração de novos acessos permanecem exclusivos do administrador principal.
- O mesmo formulário de cadastro por código de convite é usado para o segundo gestor.


## Evolução v4.3 — Gestão de usuários e metas por item

### Gestão de usuários
- Administrador Geral pode alterar, depois do cadastro:
  - nome;
  - cargo/função exibido;
  - perfil de acesso (Representante ou Subadministrador);
  - meta mensal em R$ para representantes;
  - status ativo/inativo.
- Subadministrador não altera perfis de acesso nem usuários.

### Metas por item
- Administrador Geral e Subadministrador podem criar metas por produto/item.
- Cada meta possui quantidade-alvo e período de vigência.
- O painel gerencial mostra quantidade realizada, percentual e quantos especialistas responderam no dia.
- Metas podem ser encerradas ou reativadas.

### Obrigatoriedade no painel do especialista
- Para cada meta por item ativa na data escolhida, o especialista é obrigado a responder:
  - **Vendi** → informar quantidade maior que zero;
  - **Não vendi** → quantidade registrada como zero.
- A venda diária em R$ só é salva depois que todos os itens ativos forem respondidos.
- As respostas podem ser corrigidas fazendo novo lançamento na mesma data.


## Evolução v4.4 — Permissões e reset

### Administrador Geral
- Pode resetar o painel operacional com confirmação dupla.
- O reset apaga:
  - vendas diárias;
  - metas por item;
  - respostas das metas por item;
  - convites;
  - metas mensais em R$ dos usuários.
- O reset preserva:
  - usuários;
  - logins;
  - perfil de acesso;
  - cargo/função;
  - status do Administrador Geral.
- Continua podendo alterar nome, cargo, perfil de acesso, meta mensal e status.

### Subadministrador
- Pode definir a **meta mensal de vendas em R$** dos cadastrados.
- Pode definir ou alterar o **cargo/função** dos cadastrados.
- Pode criar e acompanhar **metas por item**.
- Não pode promover/rebaixar perfil de acesso, ativar/desativar usuários ou resetar o painel.

### Demais cargos
- Cargo/função é apenas identificação profissional.
- Quem não é Administrador Geral ou Subadministrador permanece com perfil comum e acessa somente:
  - suas próprias vendas;
  - sua própria meta mensal;
  - seus próprios itens de meta;
  - seu próprio histórico.


## Evolução v4.5 — Vendas por distribuidora

### Especialista
- O lançamento diário agora é detalhado por distribuidora.
- Pode adicionar uma ou várias distribuidoras no mesmo dia.
- Informa o valor vendido em cada distribuidora.
- O **total vendido do dia é calculado automaticamente** pela soma das distribuidoras.
- Não é permitido repetir a mesma distribuidora no mesmo lançamento.
- Um dia sem vendas continua podendo ser informado com total R$ 0,00.

### Administrador Geral e Subadministrador
- Podem cadastrar e ativar/desativar distribuidoras.
- Novo painel **Vendas por distribuidora** com:
  - total de hoje;
  - total do mês;
  - participação percentual no total do mês.
- O histórico gerencial passa a mostrar a divisão da venda entre as distribuidoras.

### Dados
- Criadas as tabelas `distributors` e `daily_sales_distributors`.
- O total diário continua gravado em `daily_sales` para preservar os dashboards existentes.
- O salvamento da venda e da divisão por distribuidora é feito por RPC transacional no Supabase.
- O reset do painel limpa também os lançamentos por distribuidora, preservando o cadastro das distribuidoras.


## Evolução v4.6 — Representante por distribuidora

- Novo quadro gerencial **Vendas por representante e distribuidora**.
- Para cada representante, o gestor visualiza:
  - distribuidora;
  - valor vendido hoje;
  - valor vendido no mês;
  - participação daquela distribuidora nas vendas do representante.
- Na tabela principal da equipe, cada representante passa a exibir um resumo de quanto vendeu em cada distribuidora.
- O histórico de lançamentos mantém o detalhamento por distribuidora.
- Exportação Excel e relatório PDF incluem a coluna **Distribuidoras**.


## Evolução v4.7 — Pedidos detalhados por cliente/CNPJ

### Painel do especialista
- Novo acompanhamento de pedidos com CNPJ, Razão Social, Valor do Pedido, Número do Pedido, Distribuidora e Data.
- Clientes ficam salvos por especialista para autopreenchimento em pedidos futuros.
- Autopreenchimento funciona por CNPJ ou Razão Social.
- Histórico dos últimos pedidos do mês.
- Ranking próprio por CNPJ, somando todos os pedidos de cada cliente.

### Painel gerencial
- Ranking consolidado por CNPJ no mês selecionado.
- Mostra quantidade de pedidos, quantidade de representantes que venderam ao cliente e total vendido.
- Administrador Geral e Subadministrador podem visualizar o consolidado da equipe.

### Segurança
- Especialistas veem apenas seus próprios clientes e pedidos.
- Gestores podem visualizar todos os clientes e pedidos.
- O reset operacional apaga os pedidos detalhados, mas preserva a carteira de clientes para manter o autopreenchimento.


## Evolução v4.8 — Automação dos pedidos e metas individuais

### Pedidos como fonte das vendas
- O representante não precisa mais lançar o total diário manualmente.
- Cada pedido salvo entra automaticamente na soma do dia.
- O Supabase recalcula automaticamente:
  - total diário do representante;
  - total mensal;
  - total por distribuidora;
  - painel gerencial.
- Alterações futuras em pedidos também podem ser refletidas pelo mecanismo de sincronização do banco.

### Metas por item individualizadas
- Administrador Geral e Subadministrador passam a criar a meta por item escolhendo o representante.
- Cada meta possui:
  - representante;
  - item;
  - quantidade-alvo;
  - período.
- O gerencial mostra meta, realizado, percentual e se o representante informou o item no dia.
- O representante vê claramente a sua meta de cada item e o progresso acumulado.

### Painel do representante
- Novo resumo de vendas por distribuidora com valores de hoje e do mês.
- Ranking por CNPJ foi movido para o final do painel para melhorar a organização visual.
- O lançamento manual do total do dia foi removido; o resumo passa a ser automático pelos pedidos.


## Correção v4.9.1

- Restaurado o formulário completo de criação de meta por item na parte superior do painel ADM.
- Campos restaurados:
  - representante;
  - item/produto;
  - meta de quantidade;
  - data inicial;
  - data final;
  - botão Criar meta por item.
- Mantidos os KPIs das metas por item no topo.
- Mantida a seção Metas ativas e acompanhamento abaixo do Histórico e Correção.
- Mantidas as opções de editar, desativar e apagar distribuidoras conforme permissão.


## Evolução v5.0 — Contagem por item e exportação do representante

### Painel gerencial
- Nova tabela **Desempenho das metas por item**.
- Produtos iguais são agrupados e contados separadamente dos demais itens.
- Exemplo: B12 ORODISPERSÍVEL, COENZIMA Q10 200MG, BILIPLEX ABACAXI e BILIPLEX BOLDO aparecem em linhas independentes.
- Para cada produto o painel mostra:
  - número de representantes com meta;
  - meta total em unidades;
  - quantidade vendida;
  - quanto falta;
  - percentual atingido.
- A tabela é ordenada pelo percentual atingido, facilitando identificar os itens que estão alcançando a meta mais rápido.

### Painel do representante
- Nova tabela **Contagem das minhas metas por item**, com Meta, Realizado, Falta e % atingido.
- A contagem fica separada para cada produto.
- Adicionados botões **Exportar CSV** e **Exportar PDF** na área de pedidos.
- Os arquivos exportados incluem Data, CNPJ, Razão Social, Distribuidora, Número do Pedido, Valor e total geral.


## Evolução v5.1 — Convites corrigidos + cidade/estado dos clientes

- Corrigida a política RLS de `representative_invites`.
- Administrador Geral pode criar convites de Representante e Subadministrador.
- Subadministrador pode criar apenas convites de Representante.
- Incluídos Cidade e Estado no acompanhamento de pedidos.
- Cidade e Estado ficam salvos no cadastro do cliente e são autopreenchidos nos próximos pedidos.
- Cidade e Estado aparecem na listagem dos pedidos e nas exportações CSV/PDF.


## Evolução v5.2 — Guia lateral Base Clientes

### Nova guia lateral do representante
- Criada uma navegação lateral separando:
  - **Acompanhamento de vendas**
  - **Base Clientes**
- A Base Clientes fica fora do fluxo de vendas e pedidos.

### Cadastro da Base Clientes
Campos:
- CNPJ
- Razão Social
- Definição: Independente ou Rede
- Comprador
- Telefone
- Nome da Rede

Quando a definição for **Rede**:
- o representante informa se a unidade é **Matriz** ou **Filial**;
- se for Filial, deve selecionar qual Matriz está vinculada.

### Contadores
No topo da Base Clientes:
- **Cadastros válidos** = Independentes + Matrizes
- **Contador geral** = Independentes + Matrizes + Filiais
- também são exibidos contadores separados de Matrizes e Filiais.

### Gestão
- O representante pode editar ou excluir clientes da própria base.
- Cada representante acessa somente a própria Base Clientes.
- Administradores podem consultar os registros via políticas gerenciais do Supabase.


## Evolução v5.3 — Gerentes Regionais + reset administrativo de senha

### Gerente Regional
- Novo perfil de acesso **Gerente Regional**.
- Cada representante pode receber um Estado (ex.: PB, CE, PE).
- Cada Gerente Regional pode receber um ou vários estados (ex.: PB, PE, RN).
- O Gerente Regional acessa o painel gerencial, porém visualiza somente representantes e números pertencentes aos estados atribuídos a ele.
- O filtro de região é aplicado também no Supabase/RLS, não apenas visualmente no navegador.
- Acesso regional é somente para consulta: sem alteração de metas, correções, distribuidoras, usuários ou reset geral.
- O Administrador Geral continua com visão nacional/completa.

### Senha temporária e troca obrigatória
- Na Gestão de Equipe, o Administrador Geral ganhou o botão **Resetar senha**.
- O reset define a senha temporária: `redefinirsenha`.
- O usuário fica marcado com **Troca de senha pendente**.
- No próximo login, Representante, Sub ADM ou Gerente Regional é direcionado para uma tela obrigatória de criação de nova senha.
- O painel só é liberado depois que uma senha diferente da temporária for salva.
- A operação administrativa é feita por uma Supabase Edge Function protegida e validada como Administrador Geral.


## Evolução v5.4 — Base Clientes com Cidade/Estado, exportação e validação CNPJ × Razão

### Base Clientes
- Incluídos **Cidade** e **Estado** no cadastro, edição e listagem.
- Cidade e Estado passam a ser gravados no Supabase.
- Adicionados botões **Exportar CSV** e **Exportar PDF** para toda a Base Clientes.
- Exportações incluem CNPJ, Razão Social, Cidade, Estado, Definição, Unidade, Matriz, Comprador, Telefone e Rede.

### Validação de pedidos
- Ao lançar pedido, o sistema consulta a **Base Clientes**.
- Se o CNPJ estiver cadastrado com outra Razão Social, o pedido é bloqueado e o representante recebe a orientação para corrigir.
- Se a Razão Social estiver cadastrada com outro CNPJ, o pedido também é bloqueado.
- Quando o cadastro é válido, o sistema usa a Razão Social, Cidade e Estado oficiais da Base Clientes.
- Pedidos antigos do mês com divergência geram um alerta visível no Acompanhamento de Pedidos.
- A guia Base Clientes também mostra uma área de conflitos existentes comparando a base com cadastros/pedidos anteriores.

### Visualização
- A largura útil do site foi ampliada de 1180 px para **1540 px** em telas grandes.
- Tabelas e cartões receberam mais espaço para facilitar a leitura de dados extensos.


## Evolução v5.5 — Gerente Regional com permissões de Sub ADM + Gerente Divisional

### Gerente Regional
- Continua identificado no painel como **Gerente Regional**.
- Passa a ter as mesmas permissões operacionais do Sub ADM:
  - definir cargo/função;
  - alterar meta mensal;
  - criar e acompanhar metas por item;
  - cadastrar/editar/ativar distribuidoras;
  - corrigir lançamentos;
  - gerar convites de representantes.
- Essas permissões ficam limitadas aos especialistas dos estados atribuídos ao Gerente Regional.
- O controle de acesso foi reforçado também nas políticas RLS do Supabase.

### Gerente Divisional
- Novo perfil de acesso: **Gerente Divisional**.
- Enxerga os dados gerais de todas as regiões e todos os especialistas.
- Não possui permissão de edição.
- Novo quadro **Visão por Gerente Regional** mostra:
  - gerente;
  - estados;
  - número de especialistas;
  - vendas do mês;
  - meta da região;
  - percentual da meta.
- A tabela geral da equipe continua exibindo todos os especialistas individualmente.

### Exportações
- Tabelas do painel passam a receber automaticamente opções de:
  - **Exportar CSV**
  - **Exportar PDF**
- O mecanismo respeita os dados que o perfil tem permissão para visualizar.


## Evolução v5.6 — Painel exclusivo do Gerente Divisional

As alterações abaixo são aplicadas somente quando o usuário logado possui o perfil **Gerente Divisional**.

### Mantido / incluído no painel Divisional
- Resultado geral das vendas por Estado.
- Resultado individual de cada Especialista.
- Resultado geral por Gerente Regional.
- Gráfico de evolução acumulada de cada Estado.
- Gráfico de evolução acumulada de cada Gerente Regional.
- Resumo simples do total vendido por Distribuidora.
- Quadro de metas por item por Estado/Região.
- Gráfico percentual das metas por item por Estado.
- Exportação PDF e CSV nas tabelas, aproveitando o mecanismo geral de exportação da v5.5.
- Perfil continua somente leitura, sem permissões de edição.

### Removido somente da visão Divisional
- Ranking por CNPJ.
- Convites.
- Ranking do mês.
- Vendas por representante e distribuidora.
- Metas ativas e acompanhamento.
- Histórico e correção de lançamentos.
- Formulários de criação/edição e gestão de usuários/distribuidoras.

Os outros perfis (Administrador Geral, Sub ADM e Gerente Regional) mantêm o painel e os recursos já existentes.


## v5.7 — Layout responsivo para celular e computador

- No computador o menu do Representante continua lateral.
- Em telas de celular/tablet, o menu **Acompanhamento de vendas / Base Clientes** passa para uma barra fixa inferior, deixando toda a largura disponível para o conteúdo.
- Cabeçalho compacto no celular.
- KPIs em duas colunas no mobile.
- Cards, formulários e botões ajustados para toque.
- Campos usam tamanho de fonte adequado para evitar zoom automático em navegadores móveis.
- Tabelas mantêm todas as colunas e passam a rolar horizontalmente dentro do próprio card, sem alargar o site.
- Primeira coluna das tabelas fica fixa durante a rolagem horizontal.
- Gráficos recebem altura adequada no mobile.
- Em telas grandes, a área útil continua ampla.


## v5.8 — Exclusão de venda, moeda em Real e metas por item separadas

### Correção de vendas pelo representante
- Cada pedido/venda na lista de **Últimos pedidos** passa a ter o botão **Apagar**.
- A exclusão exige confirmação.
- Após a exclusão, o sistema recarrega todos os indicadores.
- O banco já possui gatilho de recálculo automático: ao excluir um pedido, o valor é retirado do total diário, mensal, distribuidoras e demais estatísticas.
- Ranking de clientes e relatórios também deixam de considerar a venda apagada porque são calculados a partir dos pedidos existentes.

### Formatação em R$
- Campo **Valor do pedido** do representante passa a usar máscara monetária brasileira.
- Campo **Meta mensal** em convites passa a usar máscara monetária.
- Campo **Meta mensal** na Gestão de Equipe passa a usar máscara monetária.
- Campos dinâmicos de valor por distribuidora também usam a mesma máscara.
- Edições por prompt passam a apresentar e aceitar valores em padrão brasileiro.
- Exemplo visual: `R$ 50.000,00`.

### Metas por item
- O primeiro indicador do painel administrativo agora mostra a quantidade de **metas por item cadastradas**, contando cada cadastro separadamente.
- A tabela **Desempenho das metas por item** não agrupa mais cadastros com o mesmo nome de produto.
- Cada meta cadastrada aparece em uma linha própria, com especialista, item, meta, vendido, falta e percentual.
- No painel Divisional, a quantidade de itens com meta por Estado/Região também passa a contar cada cadastro de meta separadamente.


## SAPECE v5.9 — Identidade visual

- Novo nome: SAPECE — Sistema de Apuração de Pedidos e Campanhas.
- Logotipo SAPECE aplicado ao cabeçalho em desktop e celular.
- Ícone do navegador (favicon) e ícone para adicionar à tela inicial no celular.
- Identidade azul do cabeçalho inspirada na marca.
- Nenhuma alteração nas regras de vendas, login, metas ou permissões.

Para publicar, envie **todos os 10 arquivos** presentes neste pacote à raiz do repositório (incluindo as imagens PNG).


## v6.0 — Campanhas dentro do pedido, SKUs, filtros por data e paginação

### Painel do Representante
- As metas/campanhas por item passam a ser respondidas **dentro do lançamento do pedido**.
- Para cada item em campanha o representante informa:
  - se vendeu;
  - quantidade;
  - se existe comissão;
  - valor da comissão.
- O antigo formulário separado de metas por item fica oculto no painel do representante.
- Cada pedido passa a registrar também **quantidade de SKUs**.
- O representante vê seu total de SKUs, quantidade de pedidos e média de SKUs por pedido.
- Filtro por data inicial/final atualiza vendas, pedidos, ranking de clientes e distribuidoras.

### Painel Gerencial
- Novo ranking **Horizontalização — SKUs** por especialista.
- O primeiro colocado recebe indicação de **Maior horizontalização**.
- O ranking usa total de SKUs dos pedidos no período selecionado.
- Filtro geral por datas específicas para vendas e rankings, mantendo o mês como referência das metas.

### Campanhas e comissões
- Nova tabela `order_campaign_items` relaciona cada item de campanha ao pedido.
- As quantidades informadas nos pedidos alimentam automaticamente `item_goal_reports`.
- Ao apagar um pedido, os itens de campanha ligados ao pedido são apagados por cascata e a meta é recalculada.
- Comissão fica registrada por item e por pedido.

### Listas e rankings
- Tabelas dos painéis do Representante e Gerencial passam a usar paginação automática.
- Limite visual: **10 registros por página**.
- Controles Anterior / Próxima aparecem quando necessário.

### Banco
- `sales_orders.sku_count` registra a quantidade de SKUs por pedido.
- `order_campaign_items` registra item, quantidade e comissão por pedido.


## v6.0.1 — Correção do carregamento dos itens em campanha
- Corrigido o estado de carregamento infinito no formulário de vendas.
- As campanhas agora são carregadas de forma independente das consultas de pedidos/clientes.
- A consulta busca somente campanhas ativas dentro da data do pedido e destinadas ao representante logado.
- Adicionado botão **Atualizar campanhas** para recarregar manualmente.
- Em caso de erro, o sistema mostra a mensagem real em vez de permanecer em “Carregando…”.


## v6.1 — Bloqueio de exclusão pelo representante, CNPJs positivados, comissão e comemoração

### Pedidos e campanhas enviados
- Representante não pode mais apagar nem alterar pedidos já enviados.
- Itens de campanha enviados também ficam bloqueados para alteração/exclusão pelo representante.
- Administrador Geral, Sub ADM e Gerente Regional podem excluir pedidos dentro do seu escopo.
- Ao excluir um pedido pelo painel gerencial, campanhas ligadas ao pedido e estatísticas são recalculadas automaticamente.
- Gerente Divisional continua somente leitura.

### CNPJs positivados
- Novo quadro no painel administrativo: **CNPJs positivados por representante**.
- Considera CNPJ único com pedido no período filtrado.
- Mostra representante, estado, CNPJs únicos, pedidos e valor vendido.
- Filtro por representante.
- Exportação CSV e PDF.

### Guia Comissão
- Nova guia **Comissão** no painel administrativo.
- Exibe somente itens de campanha marcados pelo representante como **com comissão**.
- Respostas “Não” não aparecem.
- Mostra data, representante, CNPJ, cliente, item, quantidade, pedido e valor da comissão.
- Filtros por representante, item e cliente/CNPJ.
- Indicadores de clientes com comissão, unidades e valor total de comissão.
- Exportação CSV e PDF.

### Meta mensal
- Quando o representante atinge a meta mensal, o painel exibe uma animação de parabéns.
- A comemoração é exibida uma vez por mês por dispositivo/navegador.
- O cálculo usa o total mensal completo, independentemente do filtro de datas aplicado na tela.


## v6.1.1 — Contagem das campanhas e Ranking por CNPJ no Representante

- Restaurada a **Contagem dos itens da campanha** no painel do representante.
- A contagem agora é somente leitura e é alimentada automaticamente pelos itens informados dentro dos pedidos.
- Mostra:
  - quantidade de itens em campanha;
  - total de unidades realizadas;
  - quantidade de metas já atingidas;
  - meta, realizado, falta e percentual por item.
- Restaurado o **Ranking por CNPJ** no painel do representante.
- O ranking usa os pedidos do período selecionado e ordena os clientes pelo maior valor vendido.
- Mantida paginação de 10 posições por página.


## v6.1.2 — Estabilização do painel de vendas
- A contagem dos itens da campanha foi isolada do carregamento das vendas.
- Se a contagem da campanha falhar, vendas, totais, pedidos e distribuidores continuam funcionando normalmente.
- A contagem usa somente consultas de leitura em `order_campaign_items`; não grava, altera ou exclui vendas.
- O Ranking por CNPJ também foi isolado para que qualquer falha visual nele não interrompa o restante do painel.
- Nenhuma mudança de banco de dados é necessária nesta correção.


## v6.1.3 — Correção do seletor de distribuidoras
As distribuidoras ativas agora carregam antes e de forma independente das campanhas, evitando que uma falha em campanhas deixe o seletor vazio.


## v6.2 — Alertas automáticos de novas vendas por e-mail
- Após um representante salvar um novo pedido, o SAPECE chama a Edge Function `notify-sale-email`.
- Destinatários:
  - adeilson.repre@gmail.com
  - adjanmca@gmail.com
- O e-mail contém representante, data, cliente, CNPJ, distribuidora, pedido, valor, SKUs e itens de campanha/comissão.
- O envio é independente do salvamento da venda: se o e-mail falhar, o pedido continua salvo.
- Para ativar o envio real, configure `RESEND_API_KEY` no Supabase.
- Recomendado verificar `sapece.com.br` no Resend e configurar `SAPECE_ALERT_FROM` como `SAPECE <alertas@sapece.com.br>`.


## v6.2.1 — Remetente suporte.sapece@gmail.com
- A Edge Function `notify-sale-email` foi atualizada para usar o serviço Brevo.
- Remetente configurado no código: `suporte.sapece@gmail.com`
- Nome do remetente: `SAPECE`
- Destinatários:
  - `adeilson.repre@gmail.com`
  - `adjanmca@gmail.com`
- O envio continua independente do salvamento do pedido.
- Para ativar o envio real, é necessário:
  1. cadastrar/verificar `suporte.sapece@gmail.com` como remetente no Brevo;
  2. criar uma chave de API no Brevo;
  3. adicionar no Supabase o segredo `BREVO_API_KEY`.
- Variáveis opcionais:
  - `SAPECE_ALERT_FROM_EMAIL` (padrão: suporte.sapece@gmail.com)
  - `SAPECE_ALERT_FROM_NAME` (padrão: SAPECE)


## v6.3 — Standby, fechamento diário e meta gerencial
- Pedidos do representante ficam em standby até o fechamento do dia.
- O representante confirma todos os pedidos em um botão grande de FINALIZAR O DIA.
- SKUs passaram a ser obrigatórios e devem ser maiores que zero em cada pedido.
- Vendas, distribuidoras e metas por item só entram nos resultados oficiais depois do fechamento diário.
- Após finalizar, o representante não pode inserir/alterar pedidos naquele dia; gerência mantém as permissões administrativas.
- O alerta por e-mail deixa de ser disparado a cada pedido e passa a ser enviado uma única vez no fechamento do dia.
- O e-mail de fechamento resume total de pedidos, total das vendas, SKUs e total de itens de campanha.
- Painel gerencial ganhou Meta Pessoal do Gerente, com realizado, projeção e percentual alimentados pelas vendas finalizadas da equipe.
- Backend: sales_orders.finalized_at, rep_day_closures e RPC finalize_sales_day.


## v6.3.1 — Padronização e restauração das comissões
- Textos digitados em cadastros e pedidos são convertidos para CAIXA ALTA antes de serem utilizados pelo sistema.
- E-mail, senha, datas, números e campos monetários não são alterados.
- A guia Comissão volta a exibir o histórico completo de comissões informado no período, inclusive registros vinculados a pedidos do dia ainda em standby.
- Os indicadores gerenciais de vendas continuam considerando somente pedidos finalizados.
